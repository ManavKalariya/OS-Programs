#include <sys/types.h>
#include <sys/wait.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<sys/stat.h>

int main(int argc, char* argv[]){
	int pipefd[2];
	int a=pipe(pipefd);
	int newstdoutfd=dup2(pipefd[1],1);
	int newstdinfd=dup2(pipefd[0],0);
	char* buf1;
	int c=fork();
	if(c==0){
		printf("Hello from Child\n");
		execl("/bin/ls","ls","-l",NULL);
	}
	else{
		wait(NULL);
		printf("Hello from Parent\n");
		execl("/bin/sort","sort",NULL);
	}
	return 1;
}
